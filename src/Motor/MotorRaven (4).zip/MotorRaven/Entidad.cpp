
#include "Entidad.hpp"
//#include "RShader.hpp"
#include <iostream>

Entidad::Entidad () {
    
}

Entidad::~Entidad () {

}

void Entidad::dibujar (glm::mat4x4 mat, unsigned int shader) {
    //std::cout << "Entro en el dibujar de entidad" << std::endl;
}
