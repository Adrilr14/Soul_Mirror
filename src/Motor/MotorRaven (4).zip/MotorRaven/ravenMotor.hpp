#pragma once

struct ravenMotor
{
    
}; //Motor gráfico propio de RavenGraphics
